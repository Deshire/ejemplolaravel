<?php

namespace sisventas\Events;

abstract class Event
{
    //
}
